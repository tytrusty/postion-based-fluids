# pbf

Build

```bash
$ cd /to/project/root/
$ mkdir build && cd build
$ cmake .. -DCMAKE_BUILD_TYPE=Release
$ make
```

The simulation is pre-loaded with a simulation example. There is a GUI to tune parameters as well. To start simulation just click start/pause button. 

